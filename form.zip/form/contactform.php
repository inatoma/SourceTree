<?php

// セレクトボックス
$kind     = array();    // 配列の初期化
$kind[1]  = '質問';
$kind[2]  = 'ご意見';
$kind[3]  = '資料請求';

// ラジオボタン
$drink  = array();    // 配列の初期化
$drink[1]  = '水';
$drink[2]  = 'ビール';
$drink[3]  = '焼酎';
$drink[4]  = '日本酒';

//セッションの開始
session_start();

// クロスサイトスクリプティング（XSS）対策
function hsc($s)
{
    return htmlspecialchars($s, ENT_QUOTES, "UTF-8");
}

// modeの初期化（入力画面）
$mode = 'input';

// 配列（エラーメッセージ）の初期化
$errmessage = array();

if (isset($_POST['back']) && $_POST['back']) {
    // backの時は何もしない
} else if (isset($_POST['check']) && $_POST['check']) {
    // checkの時は確認画面へ

    //---------- 名前チェック ----------//
    // 前後のスペース（空白）を取り除く
    $str = $_POST['name'];
    $_POST['name'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    // 未入力チェック
    if (empty($_POST['name'])) {
        $errmessage[] = "お名前を入力してください";
    }
    $_SESSION['name'] = hsc($_POST['name']);
    //---------- ふりがなチェック ----------//
    // 前後のスペース（空白）を取り除く
    $str = $_POST['yomi'];
    $_POST['yomi'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    // 未入力チェック
    if (empty($_POST['yomi'])) {
        $errmessage[] = "ふりがなを入力してください";
        // ひらがなチェック（スペース含む）
    } else if (!preg_match('/^([　 \t\r\n]|[ぁ-ん]|[ー])+$/u', $_POST['yomi'])) {
        $errmessage[] = 'ひらがなで入力して下さい';
    }
    $_SESSION['yomi'] = hsc($_POST['yomi']);
    //---------- メールアドレスチェック ----------//
    // 前後のスペース（空白）を取り除く
    $str = $_POST['email'];
    $_POST['email'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    // 未入力チェック
    if (empty($_POST['email'])) {
        $errmessage[] = "メールアドレスを入力してください";
    } else {
        // 全角英数字を半角に変換
        $_POST['email'] = mb_convert_kana($_POST['email'], "a");
        // メールアドレスの形式チェック
        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errmessage[] = 'メールアドレスを正確に入力して下さい';
        }
    }
    $_SESSION['email'] = hsc($_POST['email']);
    //---------- 電話番号チェック ----------//
    // 前後のスペース（空白）を取り除く
    $str = $_POST['number'];
    $_POST['number'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    if (!empty($_POST['number'])) {
        // 全角数字とハイフンを半角に変換
        $_POST['number'] = mb_convert_kana($_POST['number'], "na");
        //半角のハイフンを取り除く
        $_POST['number'] = mb_ereg_replace("-", "", $_POST['number']);
        // 数値チェック
        if (!ctype_digit($_POST['number'])) {
            $errmessage[] = '数値を入れて下さい';
        }
    }
    $_SESSION['number'] = hsc($_POST['number']);
    //---------- 住所 ----------//
    // 前後のスペース（空白）を取り除く
    $str = $_POST['address'];
    $_POST['address'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    $_SESSION['address'] = hsc($_POST['address']);
    //---------- 種別チェック（セレクトボックス） ----------//
    if (!$_POST['mkind']) {
        $errmessage[] = "種別を選択してください";
    } else if ($_POST['mkind'] <= 0 || $_POST['mkind'] >= 4) {
        $errmessage[] = "種別が不正です";
    }
    $_SESSION['mkind'] = hsc($_POST['mkind']);
    //---------- ちょっと一息チェック（ラジオボタン） ----------//
    if (!isset($_POST['drink']) || !$_POST['drink']) {
        $errmessage[] = "ちょっと一息を選択してください";
    } else if ($_POST['drink'] <= 0 || $_POST['drink'] >= 5) {
        $errmessage[] = "ちょっと一息が不正です";
    }
    if (isset($_POST['drink'])) {
        $_SESSION['drink'] = hsc($_POST['drink']);
    }
    $_SESSION['drink'] = hsc($_POST['drink']);
    //---------- メールマガジン登録チェック（チェックボックス） ----------//
    if (isset($_POST['info1']) && mb_strlen($_POST['info1']) > 100) {
        $errmessage[] = "メールマガジン情報1が不正です";
    }
    if (isset($_POST['info1'])) {
        $_SESSION['info1'] = hsc($_POST['info1']);
    } else {
        $_SESSION['info1'] = "";
    }

    if (isset($_POST['info2']) && mb_strlen($_POST['info2']) > 100) {
        $errmessage[] = "メールマガジン情報2が不正です";
    }
    if (isset($_POST['info2'])) {
        $_SESSION['info2'] = hsc($_POST['info2']);
    } else {
        $_SESSION['info2'] = "";
    }

    if (isset($_POST['info3']) && mb_strlen($_POST['info3']) > 100) {
        $errmessage[] = "メールマガジン情報3が不正です";
    }
    if (isset($_POST['info3'])) {
        $_SESSION['info3'] = hsc($_POST['info3']);
    } else {
        $_SESSION['info3'] = "";
    }
    //---------- お問い合わせ内容チェック ----------//
    $str = $_POST['message'];
    $_POST['message'] = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '\1', $str);
    // 未入力チェック
    if (empty($_POST['message'])) {
        $errmessage[] = "お問い合わせ内容を500文字以内で入力してください";
        // 文字数チェック
    } else if (mb_strlen($_POST['message']) > 500) {
        $errmessage[] = "お問い合わせ内容は500文字以内にしてください";
    }
    $_SESSION['message'] = hsc($_POST['message']);



    if ($errmessage) {
        // エラーがある場合はお問い合わせフォーム画面に戻る
        $mode = 'input';
    } else {
        // クロスサイトリクエストフォージェリ（CSRF）対策
        // トークンの生成（php7以降）
        $token = bin2hex(random_bytes(32));
        $_SESSION['token'] = $token;
        $mode = 'check';
    }
} else if (isset($_POST['send']) && $_POST['send']) {
    // sendの時は送信
    // トークン情報が渡ってこなかった、セッションに入っていなかった、メールアドレスがセッションになかった時
    if (!$_POST['token'] || !$_SESSION['token'] || !$_SESSION['email']) {
        $errmessage[] = '不正な処理が行われました';
        $_SESSION = array();
        $mode = 'input';
        // トークンのチェック
    } else if ($_POST['token'] != $_SESSION['token']) {
        $errmessage[] = '不正な処理が行われました';
        $_SESSION = array();
        $mode = 'input';
    } else {
        $body = "この度は、お問い合わせ頂き誠にありがとうございます。 \r\n"
            . "下記の内容でお問い合わせを受け付けました。 \r\n\r\n"
            . "お名前: " . $_SESSION['name'] . "\r\n"
            . "ふりがな: " . $_SESSION['yomi'] . "\r\n"
            . "メールアドレス: " . $_SESSION['email'] . "\r\n"
            . "電話番号: " . $_SESSION['number'] . "\r\n"
            . "住所: " . $_SESSION['address'] . "\r\n"
            . "種別: " . $kind[$_SESSION['mkind']] . "\r\n"
            . "ちょっと一息: " . $drink[$_SESSION['drink']] . "\r\n"
            . "メールマガジン登録: " . $_SESSION['info1'] . " " . $_SESSION['info2'] . " " . $_SESSION['info3'] . "\r\n"
            . "お問い合わせ内容: \r\n"
            // 改行コードを揃える
            . preg_replace("/\r\n|\r|\n/", "\r\n", $_SESSION['message']) . "\r\n\r\n"
            . "酒は人生 事務局";



        mb_language("Japanese");
        mb_internal_encoding("UTF-8");

        // ヘッダ情報設定
        $headers = [
            'MIME-Version' => '1.0',
            'Content-Transfer-Encoding' => '7bit',
            // 'Content-Transfer-Encoding' => '8bit',
            'Content-Type' => 'text/plain; charset=UTF-8',
            // 'Content-Type' => 'multipart/mixed;boundary=\"__BOUNDARY__\"\n',
            'Return-Path' => 'admin@test.com',
            'From' => '管理者 <admin@test.com>',
            'Sender' => '管理者 <admin@test.com>',
            'Reply-To' => 'admin@test.com',
            'Organization' => 'LifeIsBeautiful',
            'X-Sender' => 'admin@test.com',
            'X-Mailer' => 'Postfix/3.5.9',
            'X-Priority' => '3',
        ];
        array_walk($headers, function ($_val, $_key) use (&$header_str) {
            $header_str .= sprintf("%s: %s \r\n", trim($_key), trim($_val));
        });
        mb_send_mail($_SESSION['email'], 'お問い合わせありがとうございます', $body, $header_str);

        // CSVに出力
        // 入力内容を配列に入れる
        $msg = array($_SESSION['name'], $_SESSION['yomi'], $_SESSION['email'], $_SESSION['number'], $_SESSION['address'], $kind[$_SESSION['mkind']], $drink[$_SESSION['drink']], $_SESSION['info1'], $_SESSION['info2'], $_SESSION['info3'], $_SESSION['message']);

        $ShiftJIS = $msg;
        mb_convert_variables('SJIS-win', 'UTF-8', $ShiftJIS);
        $csv = fopen('test.csv', 'a');
        fputcsv($csv, $ShiftJIS);
        fclose($csv);

        // セッションの初期化
        $_SESSION = array();
        // session_destroy();
        $mode = 'send';
    }
} else {
    // 初回表示（GET）の時、セッションを初期化
    // $_SESSION = array();
    $_SESSION['name'] = "";
    $_SESSION['yomi'] = "";
    $_SESSION['email'] = "";
    $_SESSION['number'] = "";
    $_SESSION['address'] = "";
    $_SESSION['mkind'] = "";
    $_SESSION['drink']  = "";
    $_SESSION['info1']  = "";
    $_SESSION['info2']  = "";
    $_SESSION['info3']  = "";
    $_SESSION['message'] = "";
}
?>
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet.css">
    <title>お問い合わせフォーム</title>
</head>

<body>
    <?php if ($mode == 'input') { ?>
        <!-- 入力画面 -->
        <?php
        // エラーメッセージの表示
        if ($errmessage) {
            echo '<div class="pError">';
            // 配列内の文字列を連結、改行して表示
            echo implode('<br>', $errmessage);
            echo '</div>';
        }
        ?>
        <h1>お問い合わせフォーム</h1>
        <br>
        <form name="form" action="contactform.php" method="post" enctype="multipart/form-data" class="validationForm" novalidate>
            <div>
                <label for="name">お名前 <span class="sapn">必須</spna></label>
                <br>
                <input validate="required" class="required form" type="text" name="name" placeholder="例）山田太郎" value="<?php echo $_SESSION['name'] ?>">
            </div>
            <br>
            <div>
                <label for="yomi">ふりがな <span class="sapn">必須</spna></label>
                <br>
                <input validate="required yomi" class="form" type="text" name="yomi" placeholder="例）やまだたろう" value="<?php echo $_SESSION['yomi'] ?>">
            </div>
            <br>
            <div>
                <label for="email">メールアドレス <span class="sapn">必須</spna></label>
                <br>
                <input validate="required email" class="form" id="email" type="text" name="email" placeholder="例）tyamada@test.com" value="<?php echo $_SESSION['email'] ?>">
            </div>
            <br>
            <div>
                <label for="number">電話番号</label>
                <br>
                <input validate="phone" class="form" id="phone" type="text" name="number" placeholder="例）03-1234-5678" value="<?php echo $_SESSION['number'] ?>">
            </div>
            <br>
            <div>
                <label for="address">住所</label>
                <br>
                <input class="form" type="text" name="address" placeholder="例）東京都港区芝公園４－２－８" value="<?php echo $_SESSION['address'] ?>">
            </div>
            <br>
            <div class="selection">
                <label class="choose" for="mkind">種別</label>
                <br>
                <select name="mkind" class="mkind">
                    <?php foreach ($kind as $i => $v) { ?>
                        <?php if ($_SESSION['mkind'] == $i) { ?>
                            <option value="<?php echo $i ?>" selected><?php echo $v ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $i ?>"><?php echo $v ?></option>
                        <?php } ?>
                    <?php } ?>
                </select>
            </div>
            <br>
            <div class="selection">
                <label class="choose" for="drink">ちょっと一息</label>
                <br>
                <label class="radio"><input type="radio" name="drink" value="1" checked <?php if ($_SESSION['drink'] === "1") {
                                                                                            echo 'checked';
                                                                                        } ?>>水</label>

                <label class="radio"><input type="radio" name="drink" value="2" <?php if ($_SESSION['drink'] === "2") {
                                                                                    echo 'checked';
                                                                                } ?>>ビール</label>

                <label class="radio"><input type="radio" name="drink" value="3" <?php if ($_SESSION['drink'] === "3") {
                                                                                    echo 'checked';
                                                                                } ?>>焼酎</label>

                <label class="radio"><input type="radio" name="drink" value="4" <?php if ($_SESSION['drink'] === "4") {
                                                                                    echo 'checked';
                                                                                } ?>>日本酒</label>
                <br>
            </div>
            <br>
            <div class="selection">
                <label for="info">メールマガジン登録</label>
                <br>
                <label class="checkbox"><input type="checkbox" name="info1" value="お得な情報" checked>お得な情報</label>
                <label class="checkbox"><input type="checkbox" name="info2" value="新商品情報" checked>新商品情報</label>
                <label class="checkbox"><input type="checkbox" name="info3" value="クーポン情報" checked>クーポン情報</label>
            </div>
            <br>
            <div class="message">
                <label for="message">お問い合わせ内容（500文字以内） <span class="sapn">必須</spna></label>
                <br>
                <p><span id="textcount">0</span>/500 文字</p>
                <textarea class="form" id="message" placeholder="例）お問い合わせ内容を500文字以内で記入してください" onkeyup="StringCount('message', 'textcount')" validate=" required message" data-maxlength="500" cols="50" rows="10" name="message"><?php echo $_SESSION['message'] ?></textarea>
            </div>
            <br>
            <br>
            <div class="send">
                <input class="button" type="submit" name="check" value="入力内容の確認">
            </div>
        </form>
    <?php } else if ($mode == 'check') { ?>
        <!-- 確認画面 -->
        <h2>入力した内容を確認してください。</h2>
        <form action="contactform.php" method="post" enctype="multipart/form-data" class="confirm">
            <!-- トークンも一緒に送る -->
            <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
            <div>
                <label for="name">お名前&colon; </label>
                <br>
                <?php echo $_SESSION['name'] ?>
            </div>
            <br>
            <div>
                <label for="yomi">ふりがな&colon; </label>
                <br>
                <?php echo $_SESSION['yomi'] ?>
            </div>
            <br>
            <div>
                <label for="email">メールアドレス&colon; </label>
                <br>
                <?php echo $_SESSION['email'] ?>
            </div>
            <br>
            <div>
                <label for="number">電話番号&colon; </label>
                <br>
                <?php echo $_SESSION['number'] ?>
            </div>
            <br>
            <div>
                <label for="address">住所&colon; </label>
                <br>
                <?php echo $_SESSION['address'] ?>
            </div>
            <br>
            <div>
                <label for="mkind">種別&colon; </label>
                <br>
                <?php echo $kind[$_SESSION['mkind']] ?>
            </div>
            <br>
            <div>
                <label for="drink">ちょっと一息&colon; </label>
                <br>
                <?php echo $drink[$_SESSION['drink']] ?>
            </div>
            <br>
            <div>
                <label for="info">メールマガジン&colon; </label>
                <br>
                <?php echo $_SESSION['info1'] . "&emsp;" ?>
                <?php echo $_SESSION['info2'] . "&emsp;" ?>
                <?php echo $_SESSION['info3'] ?>
            </div>
            <br>
            <div>
                <label for="message">お問い合わせ内容&colon; </label>
                <br>
                <?php echo nl2br($_SESSION['message']) ?>
            </div>
            <br>
            <div class="send">
                <input class="button lButton" type="submit" name="back" value="修正する">
                <input class="button rButton" type="submit" name="send" value="送信する">
            </div>
        </form>
    <?php } else { ?>
        <!-- 完了画面 -->
        <h2>お問い合わせありがとうございます。</h2>
        <br>
        <p class="thanks">自動返信メールをお送りしましたのでご確認ください。</p>
        <br>
        <div class="send">
            <a href="contactform.php">
                <input class="button" type="submit" name="reset" value="戻る"><?php $mode = 'input'; ?>
            </a>
        </div>
    <?php } ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            /* 各フォームからフォーカスアウトしたときに実行 */
            $(":text,textarea").blur(function() {

                // 必須項目チェック（空白もダメ）
                if ($(this).attr('validate').match("required")) {
                    if ($(this).val() == "" || !$(this).val().match(/[^\s\t]/)) {
                        if ($(this).next().text() === "") {
                            $(this).after("<div class='jError'>入力必須項目です</div>");
                        }
                        return true;
                    } else {
                        if ($(this).next().text() !== "") $(this).next().remove();
                    }
                }

                // ひらがなチェック
                if ($(this).attr('validate').match("yomi")) {
                    if (!$(this).val().match(/^[ぁ-んー　 ]*$/)) {
                        if ($(this).next().text() === "") {
                            $(this).after("<div class='jError'>ひらがなで入力してください</div>");
                        }
                        return true;
                    } else {
                        if ($(this).next().text() !== "") $(this).next().remove();
                    }
                }

                // メールアドレスチェック（ある程度の形式チェック）
                if ($(this).attr('validate').match("email")) {
                    if (!$(this).val().match(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ui)) {
                        if ($(this).next().text() === "") {
                            $(this).after("<div class='jError'>メールアドレスの形式で入力してください</div>");
                        }
                        return true;
                    } else {
                        if ($(this).next().text() !== "") $(this).next().remove();
                    }
                }

                // 電話番号チェック（数字とハイフンのみ）
                if (!$(this).val() == "") {
                    if ($(this).attr('validate').match("phone")) {
                        if (!$(this).val().match(/^[0-9\-]+$/)) {
                            if ($(this).next().text() === "") {
                                $(this).after("<div class='jError'>数字とハイフン記号だけで入力してください</div>");
                            }
                            return true;
                        } else {
                            if ($(this).next().text() !== "") $(this).next().remove();
                        }
                    }
                }

                // お問い合わせ内容チェック（500文字まで）
                if ($(this).attr('validate').match("message")) {
                    if ($(this).val().length > 500) {
                        if ($(this).next().text() === "") {
                            $(this).after("<div class='jError'>500文字以内で記述してください</div>");
                        }
                        return true;
                    } else {
                        if ($(this).next().text() !== "") $(this).next().remove();
                    }
                }
            });

            /* 送信ボタンを押したときにエラーがあれば表示する */
            $('form').submit(function(e) {
                /* エラー表示時は送信不可 */
                if ($('div').hasClass('jError') == true) {
                    e.preventDefault();
                    alert('入力内容を確認してください');
                }
            });
        });
        /**
         * 全角から半角への変革関数
         * 入力値の英数記号を半角変換して返却
         * [引数]   strVal: 入力値
         * [返却値] String(): 半角変換された文字列
         */
        // 
        $(function() {
            $("#phone , #email").change(function() {
                var str = $(this).val();
                str = str.replace(/[Ａ-Ｚａ-ｚ０-９－！”＃＄％＆’（）＝＜＞，．？＿［］｛｝＠＾～￥]/g, function(s) {
                    return String.fromCharCode(s.charCodeAt(0) - 65248);
                });
                $(this).val(str);
            }).change();
        });
        /**
         * 文字列カウンター
         * @param {string} countTarget カウント対象のinput要素ID名
         * @param {string} resultTarget 文字列カウント結果の挿入先ID名
         */
        function StringCount(countTarget, resultTarget) {
            //文字列長取得
            var len = document.getElementById(countTarget).value.length;
            //指定ID要素へ結果を挿入
            document.getElementById(resultTarget).innerText = len;
        }
    </script>
</body>

</html>